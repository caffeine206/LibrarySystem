#ifndef __Categories_H
#define __Categories_H

class Categories {
  public:
  Categories();
  
  protected:
};

#endif
