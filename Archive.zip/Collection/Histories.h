#ifndef __Histories_H
#define __Histories_H

class Histories {
  public:
  Histories();
  
  protected:
};

#endif
