#ifndef __CheckoutController_H
#define __CheckoutController_H

#include "./Controller"

class CheckoutController : public Controller{
public:
  virtual void exec();
protected:
};

#endif
