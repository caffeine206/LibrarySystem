#ifndef __HistoryController_H
#define __HistoryController_H

#include "./Controller"

class HistoryController : public Controller{
public:
  virtual void exec();

protected:
};

#endif
