#ifndef __ReturnController_H
#define __ReturnController_H

#include "./Controller"

class ReturnController : public Controller{
public:
  virtual void exec();
protected:
};

#endif
