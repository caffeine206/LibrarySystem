#ifndef __CheckoutController_H
#define __CheckoutController_H

#include "./Controller"

class initController : public Controller{
public:
  virtual void exec();
protected:
};

#endif
