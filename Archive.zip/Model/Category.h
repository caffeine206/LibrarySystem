#ifndef __Category_H
#define __Category_H

#include "./Model.h"

class Category : public Model {
  public:
    Category(string categoryName) {}
  protected:
};

#endif
