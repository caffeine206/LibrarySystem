#ifndef __CommandValidation_H
#define __CommandValidation_H

class CommandValidation : public Validation{
  public:
  virtual void check();
  protected:
};

#endif
