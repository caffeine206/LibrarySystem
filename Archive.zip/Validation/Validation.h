#ifndef __Validation_H
#define __Validation_H

class Validation {
  public:
    virtual void check() = 0;
  protected:
};

#endif
