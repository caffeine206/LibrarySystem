#ifndef __HistoryView_H
#define __HistoryView_H

class HistoryView : TextView{
  public:
    virtual void render();
  protected:
};

#endif
