#ifndef __ListView_H
#define __ListView_H

class ListView : TextView{
  public:
    virtual void render();
  protected:
};

#endif
