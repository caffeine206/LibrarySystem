#ifndef __TextView_H
#define __TextView_H

class TextView : public View{
  public:
  virtual void render();
  void drowTable();
  protected:
  
};

#endif
