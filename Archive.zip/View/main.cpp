//
//  main.cpp
//  CSS343lab4
//
//  Created by Sota on 3/3/14.
//  Copyright (c) 2014 Sota. All rights reserved.
//

#include <iostream>
#include "../lib/InputSimulator.h"

int main(int argc, const char * argv[])
{
  InputSimulator simulator;
  simulator.exec();
  return 0;
}

