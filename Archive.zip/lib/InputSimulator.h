#ifndef __InputSimulator_H
#define __InputSimulator_H

#include "../Controller/initController.h"

class InputSimulator {
  public:
  InputSimulator();
  void exec();
  protected:
};

#endif
